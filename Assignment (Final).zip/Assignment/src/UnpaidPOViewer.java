

import javax.swing.table.DefaultTableModel;

public class UnpaidPOViewer extends POReader {
    public UnpaidPOViewer(DefaultTableModel tableModel) {
        super(tableModel);
    }

    @Override
    protected void processLine(String[] POData) {
        if ("Not Paid".equalsIgnoreCase(POData[3].trim())) {
            tableModel.addRow(new Object[]{POData[0], POData[1], POData[2], POData[3]});
        }
    }
}
