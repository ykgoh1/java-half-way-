
import javax.swing.table.DefaultTableModel;

public class AllPOViewer extends POReader {
    public AllPOViewer(DefaultTableModel tableModel) {
        super(tableModel);
    }

    @Override
    protected void processLine(String[] POData) {
        tableModel.addRow(new Object[]{POData[0], POData[1], POData[2], POData[3]});
    }
}