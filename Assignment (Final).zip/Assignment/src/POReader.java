

import javax.swing.table.DefaultTableModel;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public abstract class POReader {
    protected DefaultTableModel tableModel;

    public POReader(DefaultTableModel tableModel) {
        this.tableModel = tableModel;
    }

    public void readFileAndDisplay(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            tableModel.setRowCount(0); // Clear the table

            while ((line = br.readLine()) != null) {
                String[] POd = line.split(";");
                if (POd.length == 4) {
                    processLine(POd);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    protected abstract void processLine(String[] POData);
}