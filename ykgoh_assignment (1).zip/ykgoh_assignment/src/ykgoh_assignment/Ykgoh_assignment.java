/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ykgoh_assignment;

/**
 *
 * @author User
 */
public class Ykgoh_assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        firstPage pi1 = new firstPage();
        pi1.setVisible(true);
        
//        Manage_Item pi = new Manage_Item();
//        pi.setVisible(true);
        
      
       
    }
    
}
